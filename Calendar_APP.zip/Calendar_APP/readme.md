Before You Begin
Make sure you have Python3.x installed on your system.

We'll use sqlite database for this tutorial.

Make sure virtualenv is installed on your system.

Creates virtual environment
virtualenv -p python3 venv

source venv/bin/activate

Install requirements
pip install -r requirements.txt


run the application
flask run

api to get events between two dates :
{{ url }}/api/GetEvents
